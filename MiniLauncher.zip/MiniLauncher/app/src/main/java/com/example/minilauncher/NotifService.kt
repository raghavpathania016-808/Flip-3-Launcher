package com.example.minilauncher

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifService : NotificationListenerService() {
    override fun onListenerConnected() { instance = this }
    override fun onListenerDisconnected() { if (instance === this) instance = null }
    companion object {
        var instance: NotifService? = null
        fun current(): List<StatusBarNotification>? = try { instance?.activeNotifications?.toList() } catch (e: Exception) { null }
    }
}
