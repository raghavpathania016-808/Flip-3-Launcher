package com.example.minilauncher

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(text: String, size: Float = 16f, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        textSize = size
        isAllCaps = false
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(40, 40, 48))
        minHeight = dp(48)
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
    }

    private fun page(content: View) {
        val sv = ScrollView(this)
        sv.setBackgroundColor(Color.BLACK)
        sv.addView(content)
        setContentView(sv)
    }

    private fun column() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(8), dp(24), dp(8), dp(24))
    }

    private fun label(t: String, size: Float, color: Int = Color.WHITE) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color); gravity = Gravity.CENTER
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        showHome()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        showHome()
    }

    @Deprecated("fine for a launcher")
    override fun onBackPressed() { showHome() }

    private fun showHome() {
        val c = column()
        c.addView(TextClock(this).apply {
            format12Hour = "h:mm"; format24Hour = "HH:mm"
            textSize = 44f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        })
        c.addView(TextClock(this).apply {
            format12Hour = "EEE, d MMM"; format24Hour = "EEE, d MMM"
            textSize = 16f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
        })
        c.addView(btn("Apps") { showApps() })
        c.addView(btn("Phone") { showDialer() })
        c.addView(btn("Notifications") { showNotifs() })
        c.addView(btn("Settings") { startActivity(Intent(Settings.ACTION_SETTINGS)) })
        page(c)
    }

    private fun showApps() {
        val c = column()
        c.addView(btn("< Back") { showHome() })
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
        for (a in apps) {
            c.addView(btn(a.loadLabel(pm).toString(), 15f) {
                pm.getLaunchIntentForPackage(a.activityInfo.packageName)?.let { startActivity(it) }
            })
        }
        page(c)
    }

    private fun showDialer() {
        val c = column()
        c.addView(btn("< Back") { showHome() })
        val num = StringBuilder()
        val display = label("", 26f)
        c.addView(display)
        val keys = listOf("1","2","3","4","5","6","7","8","9","*","0","#")
        for (row in keys.chunked(3)) {
            val r = LinearLayout(this)
            for (k in row) {
                r.addView(Button(this).apply {
                    text = k; textSize = 20f
                    setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(40, 40, 48))
                    layoutParams = LinearLayout.LayoutParams(0, dp(52), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
                    setOnClickListener { num.append(k); display.text = num }
                })
            }
            c.addView(r)
        }
        c.addView(btn("Delete") { if (num.isNotEmpty()) num.setLength(num.length - 1); display.text = num })
        c.addView(btn("Call", 18f) {
            if (num.isNotEmpty()) startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(num.toString()))))
        })
        page(c)
    }

    private fun showNotifs() {
        val c = column()
        c.addView(btn("< Back") { showHome() })
        val list = NotifService.current()
        if (list == null) {
            c.addView(label("Allow notification access to see notifications here.", 14f, Color.LTGRAY))
            c.addView(btn("Grant access") {
                startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
            })
        } else if (list.isEmpty()) {
            c.addView(label("No notifications", 16f, Color.LTGRAY))
        } else {
            for (n in list) {
                val e = n.notification.extras
                val title = e.getCharSequence("android.title") ?: n.packageName
                val text = e.getCharSequence("android.text") ?: ""
                c.addView(btn("$title\n$text", 13f) {
                    try { n.notification.contentIntent?.send() } catch (_: Exception) {}
                })
            }
        }
        c.addView(btn("Refresh") { showNotifs() })
        page(c)
    }
}
