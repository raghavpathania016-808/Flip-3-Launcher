Mini Launcher (260x512 cover screen)
1. Open this folder in Android Studio, let Gradle sync.
2. Plug in the phone (USB debugging on), press Run.
3. Press Home and choose "Mini Launcher" as the default home app.
4. Open the Notifications screen once and grant notification access.
Cover screen: it only appears there if you launch it on display 1, e.g.
  adb shell am start --display 1 -n com.example.minilauncher/.MainActivity
(may need extra setup / unofficial tools on the Flip 3).
